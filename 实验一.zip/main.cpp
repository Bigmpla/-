#include <iostream>
#include<vector>
#include<algorithm>
#include <set>
#include<string>
#include <fstream>
#include <sstream>
#include<filesystem>

using namespace std;

class Grammar {
public:
    string variables;    // V�����ս��
    string terminals;    // T���ս��
    string productions;  // P������ʽ
    string start;	        // S����ʼ��

    void display() {
        cout << variables << endl;
        cout << terminals << endl;
        cout << productions << endl;
        cout << start << endl;
    }
};

int main() {
    //������ֵ
    set<string> V;
    set<string> T;

    char S;
    for(auto i: filesystem::directory_iterator("C:\\Users\\lx123\\Desktop\\all")) {
        cout<<i.path().string();
        //���ļ����ж�ȡ
        ifstream file(i.path().string()); // �滻Ϊ����ļ�·��
        if (!file.is_open()) {
            cout << "Error opening file!" << endl;
            return 1;
        }

        Grammar g;
        string line;
        int rowsNum = 0;
        while (getline(file, line)) {

            rowsNum++;
            if (rowsNum == 1 || rowsNum == 6)continue;
            switch (rowsNum) {
                case 2:
                    g.variables = line;
                    break;
                case 3:
                    g.terminals = line;
                    break;
                case 4:
                    g.productions = line;
                    break;
                case 5:
                    g.start = line;
                    break;
            }
        }
        cout << "��ȡ�������: " << endl;
        g.display();

        file.close();

        vector<string> p;
        vector<string> s;
        stringstream vStream(g.variables), tStream(g.terminals), pStream(g.productions),sStream(g.start);
        string temp;
        while (getline(vStream, temp, ',')) V.insert(temp);
        while (getline(tStream, temp, ',')) T.insert(temp);
        while (getline(pStream, temp, ',')) p.push_back(temp);
        while (getline(sStream, temp, ',')) s.push_back(temp);


        //�ж��ķ�
        int typeInARound = 4;
        int type = 4;//�ķ�����

        if(s.size() >= 2){
            type = -1;
        }
        for (string s: p) {
            type = min(type, typeInARound);
            stringstream ppStream(s);
            vector<string> left_right;
            while (getline(ppStream, temp, '-'))
                left_right.push_back(temp);

            //alpha������belta�Ҳ���
            string alpha;
            vector<string> belta;

            alpha = left_right[0];
            stringstream split1(left_right[1].substr(1));
            while (getline(split1, temp, '|')) belta.push_back(temp);

            //�ж�0���ķ�
            bool has = false;
            for (char c: alpha) {
                if (V.count(string(1, c))) {
                    has = true;
                    break;
                }
            }
            if (!has) {
                type = -1;
                break;
            }

            //�ж�1���ķ�
            typeInARound = 0;
            for (string in_b: belta) {
                if (alpha.size() <= in_b.size() || in_b == "e")
                    typeInARound = 1;
            }
            if (typeInARound != 1)continue;


            //�ж�2���ķ�
            typeInARound = 1;
            has = true;
            for (char in_a: alpha) {
                if (!V.count(string(1, in_a))) {
                    has = false;
                    break;
                }
            }
            if (!has)continue;

            //�ж�3���ķ�
            typeInARound = 2;
            has = true;
            for (string in_b: belta) {
                if ((in_b.size() == 1 && T.count(in_b)) || in_b == "e")continue;
                else if (in_b.size() == 2 && (V.count(string(1, in_b[0])) && T.count(string(1, in_b[1])) ||
                                              (V.count(string(1, in_b[1])) && T.count(string(1, in_b[0])))))
                    continue;
                else {
                    has = false;
                    break;
                }
            }
            if (!has)continue;
            typeInARound = 3;

        }
        if (typeInARound < type)
            type = typeInARound;
        //�������ķ�
        if (type == -1)
            cout << "���ķ����������ķ�" << endl;
        else
            cout << "���ķ�Ϊ " << type << " ���ķ�" << endl;

        cout<<endl;
    }
    return 0;
}

