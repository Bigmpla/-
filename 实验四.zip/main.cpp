#include<fstream>
#include<sstream>
#include<iostream>
#include<string>
#include<vector>
#include<stack>
#include<unordered_set>
using namespace std;
int precedence(char op) {
    if (op == '(') {
        return 0;
    } else if (op == '+' || op == '-') {
        return 1;
    } else if (op == '*' || op == '/') {
        return 2;
    } else if(op == ')'){
        return 3;
    }else{
        return -1;
    }
}


// �жϱ���ʽ�Ƿ�Ϸ�
bool judge(vector<string>& vars, unordered_set<string>& error_list) {
    // �������ƥ��
    int cnt = 0;
    for(int i = 0; i < vars.size() ; i++){
        if(vars[i] == "(")cnt++;
        else if(vars[i] == ")")cnt--;
    }
    if(cnt != 0){
        cout << "���Ų�ƥ�䣬����ʽ����"<<endl;
        return false;
    }

//    // ������������
//    for (string v : vars) {
//        if (error_list.count(v)) {
//            cout << "���������������ʽ����!"<<endl;
//            return false;
//        }
//    }
    return true;
}

bool isop(string s){
    if(s == "+" || s == "-" || s == "*" || s == "/" || s == "(" || s == ")")return true;
    else return false;
}


int main() {
    // ��ȡ�ļ�����
    ifstream is;
    is.open("input.txt",ios::in);
    if(!is.is_open()){
        cout<<"��ʧ��"<<endl;
        return 0;
    }
    stringstream ss;
    ss << is.rdbuf();
    string input_str = ss.str();
    is.close();

    // �ָ����
    vector<string> statements;
    string statement;
    stringstream statement_stream(input_str);
    while (getline(statement_stream, statement, ';')) {
        statements.push_back(statement);
    }

    int temp_count = 1;
    unordered_set<char> op_list = {'+','-','*','/','(',')'};
    unordered_set<string> error_list = {"**", "*-", "*+", "*/", "++", "+-", "+*", "+/", "-+", "--", "-*", "-/", "/+", "/-", "/*", "//"};

    for (string statement : statements) {
        auto equal_pos = statement.find('=');

        //û�еȺ�
        if (equal_pos == string::npos) {
            cout<<"�Ǹ�ֵ��䣬����ʽ����"<<endl;
            return 0;
        };

        string left = statement.substr(0, equal_pos);
        string right = statement.substr(equal_pos + 1);

        //vars�������б�����������ĸ�ͷ���
        vector<string>vars;

        //ȥ������ո�
        stringstream ss0(left),ss(right);
        string tmp, s1;
        left = "";
        while (getline(ss0,tmp , ' ')) {
            left += tmp;
        }
        while (getline(ss,tmp , ' ')) {
            s1 += tmp;
        }

        //���ֱ�������ͬʱ���������Ƿ�Ϸ�
        for(int i = 0; i < s1.size();i++){
            if(op_list.count(s1[i])){
                string t = "";
                if((i + 1 < s1.size() && error_list.count(t + s1[i] + s1[i + 1]))){
                    cout << "���������������ʽ����!"<<endl;
                    return 0;
                }

                vars.push_back(t + s1[i]);
            }
            else{
                int pos = i;
                while(i + 1< s1.size() && !op_list.count(s1[i + 1])){
                    i++;
                }
                vars.push_back(s1.substr(pos,i - pos + 1));
            }
        }

        //����ʽ�Ƿ�
        if (!judge(vars, error_list))return 0;

        stack<char> op_stack;  // �����ջ
        stack<string> val_stack;  // ����ջ
        vector<string> ans;
        for (string var : vars) {
            if (!isop(var)) {//�ж��ǲ���op
                val_stack.push(var);
            } else {
                if (var == "(") {
                    op_stack.push(var[0]);
                } else if (var == ")") {
                    while (!op_stack.empty() && op_stack.top() != '(') {
                        char op = op_stack.top();
                        op_stack.pop();
                        string val2 = val_stack.top();
                        val_stack.pop();
                        string val1;
                        if(!val_stack.empty()){
                            val1 = val_stack.top();
                            val_stack.pop();
                        }else{
                            val1 = "";
                        }
                        string tmp_var = "t" + to_string(temp_count++);
                        val_stack.push(tmp_var);
                        ans.push_back(tmp_var + "=" + val1 + op + val2);
                    }
                    //pop�� ��(��
                    if (!op_stack.empty()) op_stack.pop();
                } else {
                    //ջ���ȼ�����ջ�⣬��ջ
                    while (!op_stack.empty() && precedence(op_stack.top()) >= precedence(var[0])) {
                        char op = op_stack.top();
                        op_stack.pop();
                        string val2 = val_stack.top();
                        val_stack.pop();
                        string val1;
                        if(!val_stack.empty()){
                            val1 = val_stack.top();
                            val_stack.pop();
                        }else{
                            val1 = "";
                        }
                        string temp_var = "t" + to_string(temp_count++);
                        val_stack.push(temp_var);
                        ans.push_back(temp_var + "=" + val1 + op + val2);
                    }
                    op_stack.push(var[0]);
                }
            }
        }

        while (!op_stack.empty()) {
            char op = op_stack.top();
            op_stack.pop();
            string val2 = val_stack.top();
            val_stack.pop();
            string val1;
            if(!val_stack.empty()){
                val1 = val_stack.top();
                val_stack.pop();
            }else{
                val1 = "";
            }
            string temp_var = "t" + std::to_string(temp_count++);
            val_stack.push(temp_var);
            ans.push_back(temp_var + "=" + val1 + op + val2);
        }
        if(left[0] == '\n')left = left.substr(1);
        ans.push_back(left + "=" + val_stack.top());
        ofstream outfile("output.txt",ios::app);
        for(string s: ans){
            outfile << s <<endl;
        }

        outfile.close();
    }

    // д������ļ�


    return 0;
}
